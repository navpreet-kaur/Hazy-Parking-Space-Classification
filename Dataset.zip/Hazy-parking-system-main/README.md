# Hazy_parking_system_dataset
Sample 500 images (250 of train set and 250 of test set) of the Hazy parking system dataset.
